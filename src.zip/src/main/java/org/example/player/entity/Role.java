package org.example.player.entity;

public enum Role {
    STRIKER,
    MIDFIELDER,
    DEFENDER,
    GOALKEEPER
}
